NABADISHA COACHING CENTER Android project

Open this folder in Android Studio.
Then: Build > Generate Signed Bundle / APK > Android App Bundle.
Create/select a keystore and build the release AAB.

Package: com.nabadisha.coachingcenter
Version: 1.0 (code 1)
