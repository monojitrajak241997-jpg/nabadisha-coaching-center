NABADISHA COACHING CENTER - AAB READY ANDROID PROJECT

Project:
- applicationId: com.nabadisha.coachingcenter
- targetSdk: 35
- versionName: 1.0
- MainActivity loads app/src/main/assets/index.html

AAB:
1. Open this folder in Android Studio.
2. Wait for Gradle Sync to finish.
3. Build > Generate Signed Bundle / APK.
4. Select Android App Bundle.
5. Create/select a keystore and choose release.
6. Build the AAB.

Note: This environment cannot download the Gradle distribution/wrapper files,
so the ZIP is prepared for Android Studio import rather than containing a
precompiled signed AAB.
