@echo off
REM Android Studio can import this project directly.
REM If Gradle is installed on PATH, this launcher delegates to it.
gradle %*
